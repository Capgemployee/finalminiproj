﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Management_System
{
    public partial class WelcomePage : Form
    {
        private Timer time = new Timer();

        public WelcomePage()
        {
            InitializeComponent();
        }

        private void WelcomePage_Load(object sender, EventArgs e)
        {
            time.Interval = 1000;
            time.Tick += new EventHandler(IncreaseProgressBar);
            time.Start();
        }

        private void IncreaseProgressBar(object sender, EventArgs e)
        {
            progressBar1.Increment(10);
            for (int i = progressBar1.Value; i < 1000; i++)
            {
                label2.Text ="..."+Convert.ToString(progressBar1.Value)+"%";
                
            }
            if (progressBar1.Value == 10)
            {
                label1.Visible = true;
                label1.Text = "Initializing Process ...";
            }
            else if (progressBar1.Value == 40)
            {
                label1.Text = "Configure Files ... ";
            }
            else if (progressBar1.Value == 60)
            {
                label1.Text = "Fetching Data ...";
            }
            else if (progressBar1.Value == 80)
            {
                label1.Text = "Launching Application ...";
            }

            if (progressBar1.Value == progressBar1.Maximum)
            {
                time.Stop();
                LoginForm1 objLoginPage = new LoginForm1();
                this.Hide();
                objLoginPage.Show();
            }
            
        }
    }
}
