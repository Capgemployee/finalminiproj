﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;

namespace Employee_Management_System
{
    public partial class LoginForm1 : Form
    {
        public LoginForm1()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            ForgotPasswordForm objForgotPassword = new ForgotPasswordForm();
            objForgotPassword.Show();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.WhiteSmoke;
            button1.ForeColor = Color.Orange;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Orange;
            button1.ForeColor = Color.WhiteSmoke;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             EmployeeValidation validationObj = new EmployeeValidation();
                EmployeeDetails emp = new EmployeeDetails();

            emp.Username = txtUserName.Text;
            emp.Password = txtPwd.Text;
            emp.UserType = ddUserType.SelectedItem.ToString();

            DataTable table = validationObj.ShowLoginDetails(emp);

            if (table != null)
            {
                string desig = table.Rows[0]["UserType"].ToString();
                if (desig == "hr")
                {
                    this.Hide();
                    var item = new HRPortalPage();
                    item.Show();
                    
                }
                else if(desig== "manager")
                {
                    this.Hide();
                    var item = new ManagerHomePage();
                    item.Show();
                }
                if (desig == "admin")
                {
                    this.Hide();
                    var item = new AdminPortalPage();
                    item.Show();
                }

                if(desig=="employee")
                {
                    this.Hide();
                    var item = new EmployeeHomePage();
                    item.Show();
                 }
            }

        }

        private void LoginForm1_Load(object sender, EventArgs e)
        {

        }
    }
}
