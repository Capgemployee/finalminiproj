﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace Employee_Management_System
{
    public partial class HRPortalPage : Form
    {
        public HRPortalPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            var item = new LoginForm1();
            item.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void HRPortalPage_Load(object sender, EventArgs e)
        {
            EmployeeValidation validationObj = new EmployeeValidation();
           
            DataTable table = validationObj.DisplayAllEmployeeDetails();


            datagridShowData.DataSource = table;
        }
        private void Theme1()
        {

            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }

        private void Theme2()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme3()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme4()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._4;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme5()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._5;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme6()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._6;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme7()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._7;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme8()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._8;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme9()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._9;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme10()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._10;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme11()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._11;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme12()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._12;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme13()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._13;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme14()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._14;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme15()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._15;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme16()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._16;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme17()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._16;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme18()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._15;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }

        private void BasicTheme1()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(140)))), ((int)(((byte)(137)))));
        }
        private void BasicTheme2()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
        }
        private void BasicTheme3()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
        }
        private void BasicTheme4()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(171)))), ((int)(((byte)(88)))));
        }
        private void BasicTheme5()
        {
            this.BackColor = System.Drawing.Color.Salmon;
        }
        private void BasicTheme6()
        {
            this.BackColor = System.Drawing.Color.SlateGray;
        }

        private void radioButton30_CheckedChanged(object sender, EventArgs e)
        {
            Theme1();
        }

        private void radioButton77_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme2();
        }

        private void radioButton78_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme1();
        }

        private void radioButton29_CheckedChanged(object sender, EventArgs e)
        {
            Theme2();
        }

        private void radioButton28_CheckedChanged(object sender, EventArgs e)
        {
            Theme3();
        }

        private void radioButton27_CheckedChanged(object sender, EventArgs e)
        {
            Theme4();
        }

        private void radioButton26_CheckedChanged(object sender, EventArgs e)
        {
            Theme5();
        }

        private void radioButton25_CheckedChanged(object sender, EventArgs e)
        {
            Theme6();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            Theme7();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            Theme8();
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            Theme9();
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            Theme10();
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            Theme11();
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            Theme12();
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            Theme13();
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            Theme14();
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            Theme15();
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            Theme16();
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            Theme17();
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            Theme18();
        }

        private void radioButton76_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme3();
        }

        private void radioButton75_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme4();
        }

        private void radioButton74_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme5();
        }

        private void radioButton73_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme6();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                EmployeeValidation validationObj = new EmployeeValidation();
                EmployeeDetails emp = new EmployeeDetails();

                emp.EmpFName = txtFirstName.Text;
                emp.EmpLName = txtLastName.Text;
                emp.EmpDOB = Convert.ToDateTime(txtDOB.Text);
                emp.EmpDOJ = Convert.ToDateTime(txtDOJ.Text);
                emp.EmpAge = Convert.ToInt32(txtAge.Text);
                emp.EmpSalary = Convert.ToInt32(txtSalary.Text);
                if (radioMale.Checked)
                    emp.EmpGender = 'M';
                if (radioFemale.Checked)
                    emp.EmpGender = 'F';
                if (radioOther.Checked)
                    emp.EmpGender = 'O';
                emp.EmpSkills = txtSkill.Text;
                emp.EmpDesignation = txtDesignation.Text;
                emp.EmpEmailId = txtEmail.Text;
                emp.EmpAddress = txtAddress.Text;
                emp.DeptID = Convert.ToInt32(txtDeptId.Text);
                emp.EmpContactNo = txtContactNo.Text;

                bool empAdded = validationObj.AddEmployeeRecord(emp);
                if (empAdded)
                    MessageBox.Show("member Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add member record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
        
        private void button5_Click_1(object sender, EventArgs e)
        {
            int empid = Convert.ToInt32(txtxSearchByEmpID.Text);
            try
            {
                EmployeeValidation validationObj = new EmployeeValidation();
                EmployeeDetails emp = new EmployeeDetails();

                
                DataTable table = validationObj.SearchEmpByID(empid);

                if (table != null)
                {
                    lblFirstName.Text = table.Rows[0]["EmpFName"].ToString();
                    lblLastName.Text = table.Rows[0]["EmpLName"].ToString();
                    lblDOB.Text = table.Rows[0]["EmpDOB"].ToString();
                    lblDOJ.Text = table.Rows[0]["EmpDOJ"].ToString();
                    lblSalary.Text = table.Rows[0]["EmpSalary"].ToString();
                    lblDeptId.Text = table.Rows[0]["DeptID"].ToString();
                    lblGender.Text = table.Rows[0]["EmpGender"].ToString();
                    lblAge.Text = table.Rows[0]["EmpAge"].ToString();
                    lblDesignation.Text = table.Rows[0]["EmpDesignation"].ToString();
                    lblContactNo.Text = table.Rows[0]["EmpContactNo"].ToString();
                    lblEmail.Text = table.Rows[0]["EmpAddress"].ToString();
                    lblAddress.Text = table.Rows[0]["EmpEmailId"].ToString();
                    lblSkill.Text = table.Rows[0]["EmpSkills"].ToString();

                }
                else
                {
                    MessageBox.Show("Record Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void datagridShowData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                int empid = Convert.ToInt32(txtEmpID.Text);
                bool empDeleted = false;
                // EmployeeDetails emp= new EmployeeDetails();
                EmployeeValidation empValid = new EmployeeValidation();


                empDeleted = empValid.DeleteEmployeeRecord(empid);
                if (empDeleted)
                {
                    MessageBox.Show("Employee deleted Succesfully");
                }
                else
                {
                    MessageBox.Show("Record Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void datagridBirthday_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnShowBDay_Click(object sender, EventArgs e)
        {
            EmployeeValidation validationObj = new EmployeeValidation();
            DataTable table = validationObj.DisplayBirthdayDetails();
            datagridBirthday.DataSource = table;
           // btnShowBDay
        }

        private void tabPage9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            try
            {
                EmployeeValidation validationObj = new EmployeeValidation();
                EmployeeDetails emp = new EmployeeDetails();


                DataTable table = validationObj.DisplayAllEmployeeDetails();

                if (table != null)
                {
                    lblShowEmpID.Text = table.Rows[0]["EmpID"].ToString();
                    lblShowFirstName.Text = table.Rows[0]["EmpFName"].ToString();
                    lblShowLastName.Text = table.Rows[0]["EmpLName"].ToString();
                    lblShowDOB.Text = table.Rows[0]["EmpDOB"].ToString();
                    lblShowDOJ.Text = table.Rows[0]["EmpDOJ"].ToString();
                    lblShowSalary.Text = table.Rows[0]["EmpSalary"].ToString();
                    lblShowDeptId.Text = table.Rows[0]["DeptID"].ToString();
                    lblShowGender.Text = table.Rows[0]["EmpGender"].ToString();
                    lblShowAge.Text = table.Rows[0]["EmpAge"].ToString();
                    lblShowDesignation.Text = table.Rows[0]["EmpDesignation"].ToString();
                    lblShowEmail.Text = table.Rows[0]["EmpEmailId"].ToString();
                    lblShowContactNo.Text = table.Rows[0]["EmpContactNo"].ToString();
                    lblShowAddress.Text = table.Rows[0]["EmpAddress"].ToString();
                    lblShowSkills.Text = table.Rows[0]["EmpSkills"].ToString();

                }
                else
                {
                    MessageBox.Show("Record Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
